package Generics.CountMethod;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        CountBox<String> countBox = new CountBox<>();

        for (int i = 0; i < n; i++) {
            String text = scan.nextLine();
            countBox.add(text);

        }
        String input = scan.nextLine();

        System.out.println(countBox.countGreaterThan(input));

    }
}
